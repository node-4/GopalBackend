const CreateError = require("http-errors");

const Coupon = require("../../model/coupen");
const token = require("../../middleware/jwt")
const Notification = require("../../model/notification");
const Restaurant = require("../../model/restaurantCreate");

exports.createCouponByRestaurant = async (req, res, next) => {
  try {
    console.log("hit create coupon by restaurant");

    const { name, discountPercent } = req.body;
   // const restaurant = Restaurant.findById(req.user);

    const newCoupon = await Coupon.create({
      restaurantId: req.body.restaurantId,
      name,
      discountPercent,
    });
    console.log(newCoupon);

    // const promiseArray = await Promise.all([restaurant, newCoupon])

    // await Notification.create({
    //     body: `use coupon code ${promiseArray[1].name} to avail a discount of ${promiseArray[1].discountPercent} at ${promiseArray[0].name}`,
    //     isForAllUsers: true
    // });

    if (!newCoupon) return res.status(400).send({msg: "cannot create new coupon"});

    return res.status(200).send(newCoupon)
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      errorName: error.name,
      message: error.message,
    });
  }
};

exports.getAllCouponsOfRestaurant = async (req, res, next) => {
  try {
    console.log("hit restaurant get all coupons of himself ");
    const requiredResults = await Coupon.find({
      restaurantId: req.params.restaurantId,
    }).lean();

    if (requiredResults.length === 0)
      return res.status(200).json({ message: "no coupons found" });

    return res.status(200).json({ requiredResults });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      errorName: error.name,
      message: error.message,
    });
  }
};

exports.deleteCouponById = async (req, res, next) => {
  try {
    console.log("hit restaurant delete coupon by id");

    const { couponId } = req.params;

    const deletedCoupon = await Coupon.findOneAndDelete({
     // restaurantId: req.user,
      _id: couponId,
    });

    if (!deletedCoupon)
      return next(CreateError(400, "cannot delete the coupon"));

    return res.status(200).json({ message: "coupon deleted successfully" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      errorName: error.name,
      message: error.message,
    });
  }
};
