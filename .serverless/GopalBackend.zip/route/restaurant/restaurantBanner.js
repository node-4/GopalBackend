const express = require('express');
const router = express.Router();
const createError = require('http-errors');

const { restaurantAuthMiddleware,adminAuthMiddleware ,userAuthMiddleware} = require('../../middleware/jwt');
const { addBanner, getBanner, editBanner } = require('../../controller/restaurant/restaurantBanner');
const { getBannerByAdmin } = require('../../controller/admin/restaurantBanner');
const { getBannerByUser } = require('../../controller/user/restaurantBanner');

router.route('/banner').post(restaurantAuthMiddleware,/*cpUpload,*/addBanner).get(restaurantAuthMiddleware,getBanner).patch(restaurantAuthMiddleware,/*cpUpload,*/editBanner);
router.route('/adminbanner').get(adminAuthMiddleware,getBannerByAdmin)
router.route('/userbanner').get(userAuthMiddleware,getBannerByUser)


module.exports = router;
