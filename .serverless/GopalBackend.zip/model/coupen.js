const mongoose = require('mongoose');

const couponSchema = new mongoose.Schema({
    restaurantId:{
        type: mongoose.Types.ObjectId,
        ref: 'Restaurant',
        required: true
    },
    discountPercent : {
        type: Number,
        required: true,
        min: 0,
        max: 80
    },
    name:{
        type: String,
        required: true,
        uppercase: true
    }
},{
    timestamps: true
})

module.exports = mongoose.model('Coupon',couponSchema);
